BioMESH DB - Installation Guide for Microsoft Windows

Author: Carlos Carreiras
Date: 2012-07-05
---------------------------

1) Extract the contents of the "bin" folder to an appropriate location (e.g. C:\biomesh).

2) Add that folder to your system's path.

3) Set the Windows environment variable "PLINK_PROTOCOL" to the word "ssh".

4) Run the executable "unison.exe". A folder ".unison" should have been created on your home folder (it's a hidden folder).

5) Replace the "default.prf" file on the ".unison" folder with the one given.

6) Ask the BioMESH DB administrator for a private key and corresponding passphrase.

7) Store the private key file in an appropriate location (e.g. C:\biomesh\keys).

8) For your convenience, create a shortcut of the "pageant.exe" executable on your desktop.

9) In the shortcut's properties, add the location of the private key file to the "Target" field. It should look something like this: "C:\biomesh\pageant.exe C:\biomesh\keys\key.ppk".

10) To start using the BioMESH DB, start "pageant" from your desktop, and enter the passphrase.

11) When you're done for the day, exit "pageant" from the tray icon.